# Solvrex — memory export (paste this into a new Muse account)

Copy this file into the new chat so the agent there starts with the same
standing knowledge. Keep the SOP.md from this package as the workflow;
this file is the standing memory.

## The user
- Name: Mohamed Tawfiq J ("Tawfi"), Madurai, India.
- Tone: warm, direct, practical, brief. Deliver the artifact first,
  offer follow-ups second, don't stack questions.
- Prefers direct application links over roundups when job hunting
  (separate thread from Solvrex).

## Standing instructions (always on)
- Solvrex sells to local businesses in India: Website Development,
  Google Business Profile Setup, Business Process Improvement /
  Digital Enablement, Operational Support.
- ONE-SHOT MODE (set 2026-10-26): the user gives ONLY city + category
  + number of leads. The agent runs ALL SOP steps end-to-end with no
  intermediate confirmations and delivers the finished visualization
  Excel. The only step that may need the user is the Instagram login
  if the browser session has expired.
- Long-running jobs: ping the user on WhatsApp when done, with the key
  result and the file attached.
- Max 100 leads per request by default; the user routinely overrides
  by naming a larger number — treat the named number as the target.
  If a city/category cannot yield that many fresh leads, deliver what
  was found, say how many vs requested, never pad with duplicates.
- Dedupe against ALL previous batches, not just within the batch.
- Never invent data. If a field is not found, write "not found".
- Public info only. Never contact any business.
- Verified = Y only if phone or website confirmed from at least one
  source, source named in Verification Notes.
- OUTPUT (record): one Google Sheet named "Solvrex Leads", single tab
  "Leads", plain table, batches appended below each other, Hot leads
  first within each batch. No extra tabs, no complex formatting.
- OUTPUT (deliverable): the visualization Excel — Dashboard tab +
  High / Moderate / Low tabs, styled banners (navy #0A0F1A, maroon
  #302E82, subtitle #171E2E), frozen headers, gridlines hidden.
  Columns in order: Business Name, Place, Contact Number, Email,
  Website, Instagram Handle, Instagram Link, LinkedIn, Followers,
  Number of Posts, Last Post Date, Posting Frequency, Vulnerability.
  PLUS a "Pitch Deck" tab after the Dashboard (set 2026-10-26):
  Priority, Company Name, Contact Number, Owner Name, Biggest
  Vulnerability (Gap / Issue), Pitch Service, What to Tell Them
  (2-line pitch) — all leads, High first. Owner names are usually
  "not found" (owners rarely publish them); phones are the usable
  outreach field.
- Sheet writes: chunk 20 rows; on failure retry once with fewer rows,
  then report failed row ranges explicitly — never skip silently.
- Scoring: no website +3, weak website +2, profile unclaimed/incomplete +3,
  low rating/few reviews vs competitors +1, manual process +2,
  phone or email found +1. Hot 7+, Warm 4–6, Cold 0–3.
- Mandatory columns: Business name, Owner name, Contact number,
  Website, Social media accounts, Vulnerability (the one specific gap
  driving the pitch) — plus address, area, city, Maps URL, rating,
  review count, email, WhatsApp link (wa.me/<phone>, only when a
  public phone exists), website check, profile check, process check,
  competitor gap, score, tier, pitch service, 2-line pitch
  (English, names the one specific gap), verified flag, verification notes.
- Google-profile "claimed" status may be recorded as "can't verify"
  when not publicly determinable. Tab dates in YYYY-MM-DD.
- Instagram stage is built in (not optional): public research, then
  live profile visits in a logged-in browser, batches of ~40 at human
  pace, stop on any block/CAPTCHA/logout, never log out mid-sweep.
  Posting frequency is derived from the 3 latest post dates only.
- Contact/email honesty: most local businesses publish a phone but
  no email (Delhi gyms: 485/500 phones, 22/500 emails). "not found"
  is the correct value, never a guess.

## Google Sheet
- "Solvrex Leads" — ID: 1qesJSWpG0Crx1fy9kKK-h4y_NNYN5EUT862R0z_PgTo
- https://docs.google.com/spreadsheets/d/1qesJSWpG0Crx1fy9kKK-h4y_NNYN5EUT862R0z_PgTo/edit
- Lives in the USER'S Google account, not in any Muse account.
  Same Google account connected → same sheet and ID keep working.
  Different Google account → create a fresh "Solvrex Leads" sheet
  and update SHEET_ID in scripts/pipeline.py.
- As of 2026-10-26 the Leads tab holds 1,033 leads:
  6 batches of "Gyms in Delhi" (250+233+179+169+102+100),
  covering 180 Delhi localities — Delhi gyms are essentially
  exhausted; a new category/city gives better returns.
  130 qualified round-6 leads and 28 batch-1 leftovers remain
  unexported if ever wanted.

## Reference deliverable
- Final 500-lead visualization Excel (2026-10-24, revised 2026-10-26
  with Contact + Email): 322 High / 74 Moderate / 104 Low, 221
  Instagram profiles visited live (182 full, 26 location pages,
  11 gone, 1 private, 1 non-IG link); 89 of the 500 with live profile
  data, 396 with no Instagram presence. This is the format every new
  batch's Excel must match.

## Scripts (scripts/ in this package)
- pipeline.py — core (clean/dedupe, website probe, scoring, pitches,
  sheet writer). Includes the num() string-coercion fix. Imports via
  sys.path to ~/workspace/solvrex.
- round6.py — latest per-round processor template (copy and adapt
  for new rounds).
- round5.py — earlier round template.
- refresh.py — re-check an existing batch.
- rebuild_tab.py — rewrite the Leads tab from saved JSONs.
- Scripts are saved as files, not chat memory — they travel with the zip.
