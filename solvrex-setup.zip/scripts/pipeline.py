#!/usr/bin/env python3
"""Solvrex lead pipeline: clean -> enrich -> score -> pitch -> Google Sheet export."""
import json, re, os, time, subprocess
import requests
from urllib.parse import urlparse, quote
from concurrent.futures import ThreadPoolExecutor

RAW_DIR = os.path.expanduser("~/workspace/solvrex/raw")
OUT_DIR = os.path.expanduser("~/workspace/solvrex/out")
os.makedirs(OUT_DIR, exist_ok=True)
CATEGORY, CITY, DATE = "Gyms", "Delhi", "2026-10-23"
TAB_NAME = f"{CATEGORY}-{CITY}-{DATE}"
SHEET_ID = "1qesJSWpG0Crx1fy9kKK-h4y_NNYN5EUT862R0z_PgTo"
CLI = "/opt/hatch/bin/hatch_gws_cli"

# ---------------- stage 1: load & clean ----------------
def load_raw():
    recs = []
    for f in ["west.json", "south.json", "north.json", "east.json", "central.json"]:
        with open(os.path.join(RAW_DIR, f)) as fh:
            for r in json.load(fh):
                pid = r.get("place_id")
                r["place_id"] = str(pid) if pid is not None else None
                recs.append(r)
    return recs

def norm_phone(p):
    if not p:
        return None
    d = re.sub(r"\D", "", str(p))
    if len(d) == 12 and d.startswith("91"):
        d = d[2:]
    d = d.lstrip("0")
    return d or None

def num(v):
    """Coerce a rating/review-count-ish value to float; non-numeric -> 0."""
    if v is None:
        return 0
    if isinstance(v, (int, float)):
        return v
    try:
        return float(str(v).strip().split()[0])
    except (ValueError, TypeError):
        return 0

def dedupe(recs):
    seen_pid, seen_phone, seen_na, out = set(), set(), set(), []
    for r in recs:
        pid, ph = r.get("place_id"), norm_phone(r.get("phone"))
        na = (str(r.get("name") or "").lower().strip(), str(r.get("address") or "").lower().strip())
        if pid and pid in seen_pid:
            continue
        if ph and ph in seen_phone:
            continue
        if na in seen_na:
            continue
        if pid: seen_pid.add(pid)
        if ph: seen_phone.add(ph)
        seen_na.add(na)
        out.append(r)
    return out

def clean(recs):
    return [r for r in dedupe(recs) if r.get("phone") or r.get("website")]

# ---------------- stage 2: website probing ----------------
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"}
SOCIAL_DOMAINS = {"instagram.com": "instagram", "facebook.com": "facebook",
                  "fb.com": "facebook", "youtube.com": "youtube", "linkedin.com": "linkedin"}

def norm_url(u):
    u = (u or "").strip()
    if not u:
        return None
    if not re.match(r"https?://", u, re.I):
        u = "https://" + u
    return u.rstrip("/")

def site_key(u):
    try:
        p = urlparse(u.lower())
        host = p.netloc.replace("www.", "")
        return host + p.path.rstrip("/")
    except Exception:
        return u.lower()

def probe(url):
    res = {"url": url, "ok": False, "status": None, "https": False,
           "secs": None, "html": "", "final_url": url}
    try:
        t0 = time.time()
        r = requests.get(url, headers=UA, timeout=20, allow_redirects=True)
        dt = time.time() - t0
        res.update(ok=(r.status_code < 400), status=r.status_code,
                   final_url=r.url, https=r.url.startswith("https://"),
                   secs=round(dt, 2), html=(r.text or "")[:400000])
    except Exception as e:
        res["error"] = str(e)[:150]
    return res

def analyze(html):
    low = html.lower()
    has_form = bool(re.search(r"<form[\s>]", low))
    viewport = bool(re.search(r'<meta[^>]+name=["\']viewport["\']', low))
    booking_kw = bool(re.search(r"book.{0,25}(trial|session|slot|now)|join now|membership|enquir|free trial|sign.{0,5}up|register|trial class", low))
    socials = {}
    for m in re.finditer(r'https?://(?:www\.|m\.)?(instagram\.com|facebook\.com|fb\.com|youtube\.com|linkedin\.com)/[^\s"\'<>\\]+', html):
        dom = m.group(1)
        key = SOCIAL_DOMAINS.get(dom)
        u = m.group(0).rstrip(".,;)")
        if key and key not in socials and not re.search(r"/(share|sharer|intent|embed|hashtag|watch\?)", u):
            socials[key] = u
    emails = []
    for e in re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', html):
        el = e.lower()
        if el not in emails and not re.search(r"\.(png|jpe?g|gif|webp|svg|css|js)$", el) and "example." not in el:
            emails.append(e)
    wa = re.search(r'https?://(?:www\.)?(wa\.me|api\.whatsapp\.com)/[^\s"\'<>\\]+', html)
    return {"has_form": has_form, "viewport": viewport, "booking_kw": booking_kw,
            "socials": socials, "email": emails[0] if emails else None,
            "wa_link": wa.group(0) if wa else None}

def speed_label(secs):
    if secs is None:
        return "not found"
    if secs < 1.5:
        return "fast"
    if secs < 4:
        return "ok"
    return "slow"

# ---------------- stage 3: assembly, scoring, pitch ----------------
def maps_url(name, address):
    q = quote(f"{name}, {address}")
    return f"https://www.google.com/maps/search/?api=1&query={q}"

def wa_from_phone(phone):
    d = re.sub(r"\D", "", str(phone or ""))
    if len(d) == 10:
        d = "91" + d
    elif len(d) == 12 and d.startswith("91"):
        pass
    else:
        return None
    return f"https://wa.me/{d}"

PITCH = {
    "Website Development": {
        "no_site": ("Hi, I noticed {name} doesn't have a website, so people searching for a gym in {area} can't see your plans, trainers or timings online.\nAt Solvrex we build fast, mobile-friendly websites for local gyms \u2014 can I share a quick mockup of what {name}'s site could look like?"),
        "weak_site": ("Hi, I tried opening {name}'s website and {issue} \u2014 most visitors will just go back and pick another gym in {area}.\nWe rebuild slow and outdated gym websites at Solvrex so they load fast and bring trial bookings \u2014 want me to show you what's fixable on yours?"),
    },
    "Google Business Profile Setup": ("Hi, {name}'s Google listing is missing {missing}, so it looks incomplete next to other gyms in {area}.\nWe set up and polish Google Business Profiles at Solvrex \u2014 want yours fixed so it actually brings walk-ins?"),
    "Business Process Improvement / Digital Enablement": ("Hi, right now people can only reach {name} by {channel} \u2014 there's no way to book a trial online, so you'll lose everyone who won't call.\nWe set up simple online booking for gyms at Solvrex \u2014 interested in a quick demo?"),
    "Operational Support": ("Hi, {name} has {rev_text} on Google while {comp} in {area} has {comp_n} \u2014 that's what most new joiners decide on.\nWe help gyms build a steady review and follow-up system at Solvrex \u2014 want to hear how it works?"),
}

def build_leads(recs, probes):
    # group by area for competitor comparison
    by_area = {}
    for r in recs:
        by_area.setdefault(r.get("search_locality") or "Delhi", []).append(r)

    leads = []
    for r in recs:
        name = r.get("name") or "not found"
        area = r.get("search_locality") or "Delhi"
        address = r.get("address") or "not found"
        phone = r.get("phone") or "not found"
        raw_site = norm_url(r.get("website"))

        # split social-domain "websites" into socials
        site = None
        socials = {}
        if raw_site:
            host = urlparse(raw_site).netloc.lower().replace("www.", "")
            if host in SOCIAL_DOMAINS:
                socials[SOCIAL_DOMAINS[host]] = raw_site
            else:
                site = raw_site

        pr = probes.get(site_key(site)) if site else None
        web_ok = bool(pr and pr.get("ok"))
        an = analyze(pr["html"]) if web_ok else {"has_form": False, "viewport": False,
                                                 "booking_kw": False, "socials": {},
                                                 "email": None, "wa_link": None}
        for k, v in an["socials"].items():
            socials.setdefault(k, v)
        email = an["email"] or "not found"

        wa_link = an["wa_link"] or (wa_from_phone(phone) if phone != "not found" else None) or "not found"

        # website check fields
        if not site:
            w_loads, w_mob, w_https, w_form, w_speed = "not found", "not found", "not found", "not found", "not found"
        elif not web_ok:
            w_loads, w_mob, w_https, w_form, w_speed = "no", "not found", "not found", "not found", "not found"
        else:
            w_loads = "yes"
            w_mob = "yes" if an["viewport"] else "no"
            w_https = "yes" if pr["https"] else "no"
            w_form = "yes" if (an["has_form"] and an["booking_kw"]) else ("partial" if an["has_form"] else "no")
            w_speed = speed_label(pr["secs"])
        weak_site = web_ok and sum([w_https == "no", w_form == "no", w_mob == "no", w_speed == "slow"]) >= 2

        # profile check fields
        hours = r.get("hours") or "not found"
        desc = r.get("description") or "not found"
        profile_incomplete = (hours == "not found") or (desc == "not found") or (not site)
        cat = r.get("primary_category") or ""
        cat_ok = "yes" if ("gym" in cat.lower() or "fitness" in cat.lower()) else "not found"

        # process check
        parts = []
        if web_ok and an["has_form"]:
            parts.append("online form")
        if an["wa_link"]:
            parts.append("WhatsApp")
        if phone != "not found":
            parts.append("phone")
        process = " + ".join(parts) if parts else "none found"
        manual = "online form" not in process

        # competitor gap (same area, real data only)
        rating, nrev = r.get("rating"), r.get("review_count")
        others = [x for x in by_area.get(area, []) if x is not r and num(x.get("rating"))]
        others.sort(key=lambda x: (-num(x.get("rating")), -num(x.get("review_count"))))
        comps = [x for x in others if num(x.get("rating")) > num(rating)][:3]
        if comps:
            c = comps[0]
            bits = [f"In {area}, {c.get('name')} ({c.get('rating')}\u2605, {c.get('review_count')} reviews) leads on ratings"]
            if not site and c.get("website"):
                bits.append("and has a website while this gym has none")
            elif not num(rating):
                bits.append("while this gym has no published rating")
            comp_gap = " ".join(bits) + "."
            comp_names = ", ".join(x.get("name") for x in comps)
        else:
            comp_gap = f"No rated competitors found in {area} in this dataset."
            comp_names = "not found"

        # reviews gap vs competitors
        area_revs = [num(x.get("review_count")) for x in by_area.get(area, []) if num(x.get("review_count"))]
        rev_gap = False
        if area_revs:
            med = sorted(area_revs)[len(area_revs) // 2]
            rev_gap = num(nrev) < med
        elif not num(rating) and others:
            rev_gap = True

        # scoring
        score, gaps = 0, {}
        if not site:
            score += 3; gaps["website"] = 3
        elif weak_site:
            score += 2; gaps["website"] = 2
        if profile_incomplete:
            score += 3; gaps["profile"] = 3
        if rev_gap:
            score += 1; gaps["reviews"] = 1
        if manual:
            score += 2; gaps["process"] = 2
        if phone != "not found" or email != "not found":
            score += 1
        tier = "Hot" if score >= 7 else ("Warm" if score >= 4 else "Cold")

        # vulnerability + pitch service (priority: website > profile > process > reviews)
        if not site:
            vuln = "No website \u2014 invisible beyond Maps; can't show plans, trainers or timings."
            service, pitch = "Website Development", PITCH["Website Development"]["no_site"].format(name=name, area=area)
        elif weak_site:
            issues = []
            if w_https == "no": issues.append("it's not on HTTPS")
            if w_form == "no": issues.append("there's no enquiry/booking form")
            if w_speed == "slow": issues.append("it loads slowly")
            if w_mob == "no": issues.append("it's not mobile-friendly")
            vuln = "Weak website: " + ", ".join(issues) + "."
            service = "Website Development"
            pitch = PITCH["Website Development"]["weak_site"].format(name=name, area=area, issue=", ".join(issues))
        elif profile_incomplete:
            missing = [m for m, v in [("hours", hours), ("description", desc), ("website link", site)] if v in ("not found", None)]
            vuln = f"Google profile incomplete \u2014 missing {', '.join(missing)}; looks unfinished next to competitors."
            service = "Google Business Profile Setup"
            pitch = PITCH["Google Business Profile Setup"].format(name=name, area=area, missing=" and ".join(missing))
        elif manual:
            ch = "phone/WhatsApp" if "WhatsApp" in process else "phone"
            vuln = f"Manual booking only ({process}) \u2014 no online trial booking; loses visitors who won't call."
            service = "Business Process Improvement / Digital Enablement"
            pitch = PITCH["Business Process Improvement / Digital Enablement"].format(name=name, channel=ch)
        else:
            comp = comps[0].get("name") if comps else "top gyms nearby"
            comp_n = f"{comps[0].get('review_count')} reviews" if comps else "hundreds of reviews"
            rev_text = f"only {nrev} reviews" if nrev else "no published reviews"
            vuln = f"Weak review presence ({rev_text}) vs competitors in {area}."
            service = "Operational Support"
            pitch = PITCH["Operational Support"].format(name=name, area=area, rev_text=rev_text, comp=comp, comp_n=comp_n)

        verified = "Y" if (phone != "not found" or web_ok) else "N"
        vnotes = []
        if phone != "not found":
            vnotes.append("phone from Google Maps place data (web search)")
        if web_ok:
            vnotes.append(f"website confirmed via HTTP probe (HTTP {pr['status']})")

        leads.append({
            "name": name, "category": r.get("primary_category") or "not found",
            "address": address, "area": area, "city": CITY,
            "maps_url": maps_url(name, address) if address != "not found" else "not found",
            "rating": rating if rating is not None else "not found",
            "review_count": nrev if nrev is not None else "not found",
            "phone": phone, "email": email, "owner": "not found",
            "website": site or "not found",
            "instagram": socials.get("instagram", "not found"),
            "facebook": socials.get("facebook", "not found"),
            "youtube": socials.get("youtube", "not found"),
            "linkedin": socials.get("linkedin", "not found"),
            "whatsapp": wa_link,
            "w_loads": w_loads, "w_mobile": w_mob, "w_https": w_https,
            "w_form": w_form, "w_speed": w_speed,
            "claimed": "can't verify", "hours": hours,
            "profile_site": site or "not found", "description": desc,
            "photos": "not found", "cat_ok": cat_ok,
            "process": process, "comp_gap": comp_gap, "vuln": vuln,
            "score": score, "tier": tier, "service": service, "pitch": pitch,
            "verified": verified, "vnotes": "; ".join(vnotes) or "not found",
        })
    return leads

HEADER = ["Business name", "Category", "Address", "Area", "City", "Maps URL",
          "Rating", "Review count", "Business phone", "Email", "Owner name", "Website",
          "Instagram", "Facebook", "YouTube", "LinkedIn", "WhatsApp link",
          "Website loads", "Mobile-friendly", "HTTPS", "Enquiry/Booking form", "Speed",
          "Profile claimed", "Hours", "Profile website link", "Description", "Photo count",
          "Category correct", "Booking process", "Competitor gap", "Vulnerability",
          "Score", "Tier", "Pitch service", "Pitch message", "Verified", "Verification notes"]

def row(l):
    return [l["name"], l["category"], l["address"], l["area"], l["city"], l["maps_url"],
            l["rating"], l["review_count"], l["phone"], l["email"], l["owner"], l["website"],
            l["instagram"], l["facebook"], l["youtube"], l["linkedin"], l["whatsapp"],
            l["w_loads"], l["w_mobile"], l["w_https"], l["w_form"], l["w_speed"],
            l["claimed"], l["hours"], l["profile_site"], l["description"], l["photos"],
            l["cat_ok"], l["process"], l["comp_gap"], l["vuln"],
            l["score"], l["tier"], l["service"], l["pitch"], l["verified"], l["vnotes"]]

def cli(*args, json_body=None):
    cmd = [CLI, "sheets"] + list(args)
    if json_body is not None:
        cmd += ["--json", json.dumps(json_body)]
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if p.returncode != 0:
        raise RuntimeError(f"CLI failed: {p.stderr[:500]}")
    return json.loads(p.stdout)

NEW_HEADER = ["Batch date", "Batch"] + HEADER
NEW_TAB = "Leads"
BATCH_SIZE = 100

def slugify(category, city, date):
    return f"{category.lower()}-{city.lower()}-{date}"

def write_chunk(tab, start_row, chunk):
    """Write one chunk; on failure retry once with half-size chunks; return failed (start,end) ranges."""
    def put(rng, vals):
        p = subprocess.run([CLI, "sheets", "spreadsheets", "values", "update",
                            "--params", json.dumps({"spreadsheetId": SHEET_ID, "range": rng,
                                                    "valueInputOption": "USER_ENTERED"}),
                            "--json", json.dumps({"values": vals})],
                           capture_output=True, text=True, timeout=120)
        if p.returncode != 0:
            raise RuntimeError(p.stderr[:300])
    try:
        put(f"{tab}!A{start_row}", chunk)
        return []
    except RuntimeError:
        failed, half = [], max(1, len(chunk) // 2)
        for i in range(0, len(chunk), half):
            sub = chunk[i:i + half]
            try:
                put(f"{tab}!A{start_row + i}", sub)
            except RuntimeError:
                failed.append((start_row + i, start_row + i + len(sub) - 1))
        return failed

def ensure_tab():
    meta = cli("spreadsheets", "get", "--params", json.dumps({"spreadsheetId": SHEET_ID}))
    titles = [s["properties"]["title"] for s in meta["sheets"]]
    if NEW_TAB not in titles:
        subprocess.run([CLI, "sheets", "spreadsheets", "batchUpdate",
                        "--params", json.dumps({"spreadsheetId": SHEET_ID}),
                        "--json", json.dumps({"requests": [{"addSheet": {"properties": {"title": NEW_TAB}}}]}),
                        ], capture_output=True, text=True, timeout=60)
    cur = cli("spreadsheets", "values", "get", "--params",
              json.dumps({"spreadsheetId": SHEET_ID, "range": f"{NEW_TAB}!A1:A10000"}))
    return len(cur.get("values", []))  # 0 if empty

def export_batch(leads, batch_num, batch_date, batch_label):
    start = (batch_num - 1) * BATCH_SIZE
    window = leads[start:start + BATCH_SIZE]
    if not window:
        print(f"batch {batch_num}: nothing left to export")
        return []
    existing = ensure_tab()
    rows = []
    if existing == 0:
        rows.append(NEW_HEADER)
    rows += [[batch_date, batch_label] + row(l) for l in window]
    failed, CH = [], 20
    base = existing + 1
    for i in range(0, len(rows), CH):
        chunk = rows[i:i + CH]
        f = write_chunk(NEW_TAB, base + i, chunk)
        failed.extend(f)
        print(f"rows {base + i}-{base + i + len(chunk) - 1}: {'FAILED ' + str(f) if f else 'ok'}")
    remaining = len(leads) - (start + len(window))
    hot = sum(1 for l in window if l["tier"] == "Hot")
    warm = sum(1 for l in window if l["tier"] == "Warm")
    cold = sum(1 for l in window if l["tier"] == "Cold")
    print(f"batch {batch_num} exported: {len(window)} leads (Hot={hot} Warm={warm} Cold={cold}); {remaining} remaining")
    return failed

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--category", default=CATEGORY)
    ap.add_argument("--city", default=CITY)
    ap.add_argument("--date", default=DATE)
    ap.add_argument("--raw-dir", default=RAW_DIR)
    ap.add_argument("--batch", type=int, default=1)
    ap.add_argument("--export-only", action="store_true")
    a = ap.parse_args()
    slug = slugify(a.category, a.city, a.date)
    out_path = os.path.join(OUT_DIR, f"{slug}.json")
    batch_label = f"{a.category} in {a.city}"

    if a.export_only:
        leads = json.load(open(out_path))
        print(f"loaded {len(leads)} leads from {out_path}")
    else:
        files = [f for f in os.listdir(a.raw_dir) if f.endswith(".json")]
        recs_raw = []
        for f in files:
            with open(os.path.join(a.raw_dir, f)) as fh:
                for r in json.load(fh):
                    pid = r.get("place_id")
                    r["place_id"] = str(pid) if pid is not None else None
                    recs_raw.append(r)
        recs = clean(recs_raw)
        print(f"raw={len(recs_raw)} qualified_after_clean={len(recs)}")
        sites = {}
        for r in recs:
            u = norm_url(r.get("website"))
            if u and urlparse(u).netloc.lower().replace("www.", "") not in SOCIAL_DOMAINS:
                sites.setdefault(site_key(u), u)
        print(f"unique websites to probe: {len(sites)}")
        probes = {}
        with ThreadPoolExecutor(max_workers=12) as ex:
            for k, pr in zip(sites.keys(), ex.map(probe, sites.values())):
                probes[k] = pr
        print(f"websites OK: {sum(1 for p in probes.values() if p['ok'])}/{len(probes)}")
        leads = build_leads(recs, probes)
        order = {"Hot": 0, "Warm": 1, "Cold": 2}
        leads.sort(key=lambda l: (order[l["tier"]], -l["score"],
                                  -(l["review_count"] if isinstance(l["review_count"], int) else 0),
                                  l["name"]))
        with open(out_path, "w") as fh:
            json.dump(leads, fh, ensure_ascii=False)
        print(f"saved {len(leads)} leads to {out_path}")

    failed = export_batch(leads, a.batch, a.date, batch_label)
    if failed:
        print(f"FAILED ROW RANGES (not skipped, need attention): {failed}")

if __name__ == "__main__":
    main()
