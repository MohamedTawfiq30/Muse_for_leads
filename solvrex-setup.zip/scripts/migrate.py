#!/usr/bin/env python3
"""Migrate Solvrex Leads to the new format: single 'Leads' tab, plain table."""
import json, subprocess, sys

SHEET_ID = "1qesJSWpG0Crx1fy9kKK-h4y_NNYN5EUT862R0z_PgTo"
CLI = "/opt/hatch/bin/hatch_gws_cli"
NEW_TAB = "Leads"

HEADER = ["Business name", "Category", "Address", "Area", "City", "Maps URL",
          "Rating", "Review count", "Business phone", "Email", "Owner name", "Website",
          "Instagram", "Facebook", "YouTube", "LinkedIn", "WhatsApp link",
          "Website loads", "Mobile-friendly", "HTTPS", "Enquiry/Booking form", "Speed",
          "Profile claimed", "Hours", "Profile website link", "Description", "Photo count",
          "Category correct", "Booking process", "Competitor gap", "Vulnerability",
          "Score", "Tier", "Pitch service", "Pitch message", "Verified", "Verification notes"]
NEW_HEADER = ["Batch date", "Batch"] + HEADER

def row(l):
    return [l["name"], l["category"], l["address"], l["area"], l["city"], l["maps_url"],
            l["rating"], l["review_count"], l["phone"], l["email"], l["owner"], l["website"],
            l["instagram"], l["facebook"], l["youtube"], l["linkedin"], l["whatsapp"],
            l["w_loads"], l["w_mobile"], l["w_https"], l["w_form"], l["w_speed"],
            l["claimed"], l["hours"], l["profile_site"], l["description"], l["photos"],
            l["cat_ok"], l["process"], l["comp_gap"], l["vuln"],
            l["score"], l["tier"], l["service"], l["pitch"], l["verified"], l["vnotes"]]

def run(*args):
    p = subprocess.run([CLI, "sheets"] + list(args), capture_output=True, text=True, timeout=120)
    if p.returncode != 0:
        raise RuntimeError(f"CLI failed: {p.stderr[:400]}")
    return json.loads(p.stdout)

def write_chunk(tab, start_row, chunk):
    """Write one chunk; on failure retry once with half chunks; report failures."""
    rng = f"{tab}!A{start_row}"
    try:
        run("spreadsheets", "values", "update", "--params",
            json.dumps({"spreadsheetId": SHEET_ID, "range": rng, "valueInputOption": "USER_ENTERED"}),
            "--json", json.dumps({"values": chunk}))
        return []
    except RuntimeError:
        failed = []
        half = max(1, len(chunk) // 2)
        for i in range(0, len(chunk), half):
            sub = chunk[i:i + half]
            try:
                run("spreadsheets", "values", "update", "--params",
                    json.dumps({"spreadsheetId": SHEET_ID,
                                "range": f"{tab}!A{start_row + i}",
                                "valueInputOption": "USER_ENTERED"}),
                    "--json", json.dumps({"values": sub}))
            except RuntimeError:
                failed.append((start_row + i, start_row + i + len(sub) - 1))
        return failed

def main():
    leads = json.load(open("/home/hatch/workspace/solvrex/out/gyms-delhi-2026-10-23.json"))
    meta = run("spreadsheets", "get", "--params", json.dumps({"spreadsheetId": SHEET_ID}))
    titles = [s["properties"]["title"] for s in meta["sheets"]]
    if NEW_TAB not in titles:
        run("spreadsheets", "batchUpdate", "--params", json.dumps({"spreadsheetId": SHEET_ID}),
            "--json", json.dumps({"requests": [{"addSheet": {"properties": {"title": NEW_TAB}}}]}))
        print("created tab", NEW_TAB)
    values = [NEW_HEADER] + [["2026-10-23", "Gyms in Delhi"] + row(l) for l in leads]
    failed = []
    CH = 20
    for i in range(0, len(values), CH):
        chunk = values[i:i + CH]
        f = write_chunk(NEW_TAB, i + 1, chunk)
        failed.extend(f)
        print(f"rows {i + 1}-{i + len(chunk)}: {'FAILED ' + str(f) if f else 'ok'}")
    # verify
    cur = run("spreadsheets", "values", "get", "--params",
              json.dumps({"spreadsheetId": SHEET_ID, "range": f"{NEW_TAB}!A1:A1000"}))
    n = len(cur.get("values", []))
    print(f"Leads tab now has {n} rows (expected {len(values)})")
    if n != len(values):
        print("ROW COUNT MISMATCH - not deleting old tabs", file=sys.stderr)
        sys.exit(1)
    # delete old tabs
    meta = run("spreadsheets", "get", "--params", json.dumps({"spreadsheetId": SHEET_ID}))
    ids = {s["properties"]["title"]: s["properties"]["sheetId"] for s in meta["sheets"]}
    reqs = [{"deleteSheet": {"sheetId": ids[t]}} for t in
            ["Gyms-Delhi-2026-10-23", "Summary"] if t in ids]
    if reqs:
        run("spreadsheets", "batchUpdate", "--params", json.dumps({"spreadsheetId": SHEET_ID}),
            "--json", json.dumps({"requests": reqs}))
        print("deleted old tabs:", [t for t in ["Gyms-Delhi-2026-10-23", "Summary"] if t in ids])
    if failed:
        print("FAILED ROW RANGES:", failed)
    else:
        print("migration complete, no failures")

if __name__ == "__main__":
    main()
