#!/usr/bin/env python3
"""Rebuild the Leads tab cleanly: header + batch1 (250) + batch2 (233), in order."""
import json, os, sys

sys.path.insert(0, os.path.expanduser("~/workspace/solvrex"))
import pipeline as P

OUT = os.path.expanduser("~/workspace/solvrex/out")

def main():
    b1 = json.load(open(os.path.join(OUT, "gyms-delhi-2026-10-23-refresh1.json")))
    b2 = json.load(open(os.path.join(OUT, "gyms-delhi-2026-10-23-set2.json")))
    print(f"batch1: {len(b1)}, batch2: {len(b2)}")
    rows = [P.NEW_HEADER]
    rows += [["2026-10-23", "Gyms in Delhi"] + P.row(l) for l in b1]
    rows += [["2026-10-23", "Gyms in Delhi batch 2"] + P.row(l) for l in b2]
    print(f"total rows to write: {len(rows)}")
    failed, CH = [], 20
    for i in range(0, len(rows), CH):
        chunk = rows[i:i + CH]
        f = P.write_chunk(P.NEW_TAB, i + 1, chunk)
        failed.extend(f)
        if f:
            print(f"rows {i+1}-{i+len(chunk)}: FAILED {f}")
    print(f"chunks: {(len(rows)+CH-1)//CH}, failed: {failed or 'none'}")
    cur = P.cli("spreadsheets", "values", "get", "--params",
                json.dumps({"spreadsheetId": P.SHEET_ID, "range": f"{P.NEW_TAB}!A1:A10000"}))
    n = len(cur.get("values", []))
    print(f"tab rows now: {n} (expected {len(rows)})")
    assert n == len(rows), "ROW COUNT MISMATCH"
    # spot check boundaries
    for rng in ["A2:C2", f"A251:C251", f"A252:C252", f"A{n}:C{n}"]:
        v = P.cli("spreadsheets", "values", "get", "--params",
                  json.dumps({"spreadsheetId": P.SHEET_ID, "range": f"{P.NEW_TAB}!{rng}"}))
        print(rng, "->", v.get("values"))
    print("rebuild OK")

if __name__ == "__main__":
    main()
