#!/usr/bin/env python3
"""Refresh the 250 Delhi gym leads: fresh place details + website re-probe, rewrite sheet rows."""
import json, os, re, sys, subprocess
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, os.path.expanduser("~/workspace/solvrex"))
import pipeline as P

RAW_DIR = os.path.expanduser("~/workspace/solvrex/raw")
OUT_DIR = os.path.expanduser("~/workspace/solvrex/out")
BATCH_DATE, BATCH_LABEL = "2026-10-23", "Gyms in Delhi"

def fmt_time(t):
    s = str(t).strip()
    if not re.fullmatch(r"\d{3,4}", s):
        return s or "not found"
    s = s.zfill(4)
    h, m = int(s[:2]), s[2:]
    ap = "AM" if h < 12 else "PM"
    h = h % 12 or 12
    return f"{h}:{m} {ap}"

def fmt_hours(oh):
    if not oh:
        return None
    parts = []
    for e in oh:
        d = e.get("day_of_week", "").title()
        parts.append(f"{d}: {fmt_time(e.get('open_time', ''))} - {fmt_time(e.get('close_time', ''))}")
    return "; ".join(parts)

def cli_details(ids):
    p = subprocess.run(["/opt/hatch/bin/places", "details"] + ids,
                       capture_output=True, text=True, timeout=120)
    if p.returncode != 0:
        raise RuntimeError(p.stderr[:300])
    return json.loads(p.stdout)

def main():
    # 1. reload raw + clean (deterministic, same 278 as before)
    recs_raw = []
    for f in sorted(os.listdir(RAW_DIR)):
        if f.endswith(".json"):
            with open(os.path.join(RAW_DIR, f)) as fh:
                for r in json.load(fh):
                    pid = r.get("place_id")
                    r["place_id"] = str(pid) if pid is not None else None
                    recs_raw.append(r)
    recs = P.clean(recs_raw)
    print(f"recs: {len(recs)}")
    old_leads = {l["name"]: l for l in
                 json.load(open(os.path.join(OUT_DIR, "gyms-delhi-2026-10-23.json")))}

    # 2. fresh details in batches (with disk cache)
    cache_path = os.path.join(OUT_DIR, "details-cache.json")
    cache = json.load(open(cache_path)) if os.path.exists(cache_path) else {}
    det_map, failed_ids = {}, []
    ids = [r["place_id"] for r in recs]
    todo_ids = [i for i in ids if i not in cache]
    for i in range(0, len(todo_ids), 25):
        chunk = todo_ids[i:i + 25]
        try:
            for k, v in cli_details(chunk).items():
                cache[k] = v
        except RuntimeError as e:
            print(f"details batch {i}-{i + len(chunk)} failed: {e}")
            failed_ids.extend(chunk)
    json.dump(cache, open(cache_path, "w"))
    det_map = {i: cache[i] for i in ids if i in cache}
    print(f"details ok: {len(det_map)}/{len(ids)}, failed: {len(failed_ids)}")

    def pick_phone(phs):
        if isinstance(phs, dict):
            return phs.get("e164_number") or phs.get("display_number")
        if isinstance(phs, list) and phs:
            p0 = phs[0]
            return p0 if isinstance(p0, str) else p0.get("e164_number")
        return None

    changed = {"phone": 0, "website": 0, "rating": 0, "closed": 0}
    for r in recs:
        d = (det_map.get(r["place_id"]) or {}).get("details") or {}
        if not d:
            continue
        new_phone = pick_phone(d.get("phone_numbers"))
        if new_phone and new_phone != r.get("phone"):
            changed["phone"] += 1
            r["phone"] = new_phone
        web = next((l["url"] for l in d.get("links", []) if l.get("type") == "website"), None)
        if web and web != r.get("website"):
            changed["website"] += 1
            r["website"] = web
        hrs = fmt_hours(d.get("opening_hours"))
        if hrs:
            r["hours"] = hrs
        if d.get("description"):
            r["description"] = d["description"]
        rt = d.get("rating")
        if isinstance(rt, dict) and rt.get("avg_rating"):
            if r.get("rating") != rt["avg_rating"]:
                changed["rating"] += 1
            r["rating"] = rt["avg_rating"]
            r["review_count"] = rt.get("num_rating")
        if d.get("is_permanently_closed") or d.get("is_temporarily_closed"):
            changed["closed"] += 1
            r["_now_closed"] = True
        for l in d.get("links", []):
            if l.get("type") == "fb_page" and l.get("url"):
                r["_fb"] = l["url"]
            if l.get("type") == "ig_account" and l.get("url"):
                r["_ig"] = l["url"]
        addr = d.get("address") or {}
        sa = addr.get("streetaddress")
        if sa:
            r["address"] = ", ".join(x for x in
                                     [sa, addr.get("city"), addr.get("stateprovince"),
                                      addr.get("postalcode"), addr.get("country")] if x)

    # 3. re-probe websites
    sites = {}
    for r in recs:
        u = P.norm_url(r.get("website"))
        if u and P.urlparse(u).netloc.lower().replace("www.", "") not in P.SOCIAL_DOMAINS:
            sites.setdefault(P.site_key(u), u)
    print(f"probing {len(sites)} sites")
    probes = {}
    with ThreadPoolExecutor(max_workers=12) as ex:
        for k, pr in zip(sites.keys(), ex.map(P.probe, sites.values())):
            probes[k] = pr
    print(f"websites OK: {sum(1 for p in probes.values() if p['ok'])}/{len(probes)}")

    # 4. rebuild + sort
    leads = P.build_leads(recs, probes)
    for l, r in zip(leads, recs):
        if l["facebook"] == "not found" and r.get("_fb"):
            l["facebook"] = r["_fb"]
        if l["instagram"] == "not found" and r.get("_ig"):
            l["instagram"] = r["_ig"]
        if r.get("_now_closed"):
            l["vnotes"] += "; now shows closed on Maps - verify before outreach"
    order = {"Hot": 0, "Warm": 1, "Cold": 2}
    leads.sort(key=lambda l: (order[l["tier"]], -l["score"],
                              -(l["review_count"] if isinstance(l["review_count"], int) else 0),
                              l["name"]))
    top = leads[:250]
    tier_changed = sum(1 for l in top if old_leads.get(l["name"], {}).get("tier") != l["tier"])
    score_changed = sum(1 for l in top if old_leads.get(l["name"], {}).get("score") != l["score"])
    new_names = [l["name"] for l in top if l["name"] not in old_leads]
    dropped_names = [n for n in old_leads if n not in {l["name"] for l in top}]
    print(f"tier changed: {tier_changed}, score changed: {score_changed}")
    print(f"new in top250: {len(new_names)}, dropped: {len(dropped_names)}")
    json.dump(top, open(os.path.join(OUT_DIR, "gyms-delhi-2026-10-23-refresh1.json"), "w"),
              ensure_ascii=False)

    # 5. rewrite sheet rows 2-251
    rows = [[BATCH_DATE, BATCH_LABEL] + P.row(l) for l in top]
    failed, CH, base = [], 20, 2
    for i in range(0, len(rows), CH):
        chunk = rows[i:i + CH]
        f = P.write_chunk(P.NEW_TAB, base + i, chunk)
        failed.extend(f)
        print(f"rows {base + i}-{base + i + len(chunk) - 1}: {'FAILED ' + str(f) if f else 'ok'}")
    cur = P.cli("spreadsheets", "values", "get", "--params",
                json.dumps({"spreadsheetId": P.SHEET_ID, "range": f"{P.NEW_TAB}!A1:A1000"}))
    print(f"tab rows now: {len(cur.get('values', []))} (expected 251)")
    print("CHANGES:", json.dumps(changed))
    if failed:
        print(f"FAILED ROW RANGES: {failed}")
    else:
        print("refresh complete, no write failures")

if __name__ == "__main__":
    main()
