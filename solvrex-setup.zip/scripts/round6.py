#!/usr/bin/env python3
"""Round 5: new Delhi gym leads from raw3. Dedupe vs batches 1+2, clean, enrich,
export first 100 to Leads tab (standing 100/request rule)."""
import json, os, re, sys, glob
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, os.path.expanduser("~/workspace/solvrex"))
import pipeline as P

RAW_DIRS = [os.path.expanduser("~/workspace/solvrex/raw"),
            os.path.expanduser("~/workspace/solvrex/raw2"),
            os.path.expanduser("~/workspace/solvrex/raw3"),
            os.path.expanduser("~/workspace/solvrex/raw4"),
            os.path.expanduser("~/workspace/solvrex/raw5")]
RAW6 = os.path.expanduser("~/workspace/solvrex/raw6")
OUT = os.path.expanduser("~/workspace/solvrex/out")
BATCH_DATE, BATCH_LABEL = "2026-10-23", "Gyms in Delhi batch 6"
LIMIT = 100  # standing 100/request rule
JUNK = re.compile(r"room for rent|rental|dudhwala|dairy|villa|\bpg\b|hostel|dhaba|restaurant|salon|spa center", re.I)

def load_dir(d):
    recs = []
    for f in sorted(glob.glob(os.path.join(d, "*.json"))):
        for r in json.load(open(f)):
            pid = r.get("place_id")
            r["place_id"] = str(pid) if pid is not None else None
            recs.append(r)
    return recs

def main():
    excl_pid, excl_ph, excl_na = set(), set(), set()
    for d in RAW_DIRS:
        for r in load_dir(d):
            if r.get("place_id"):
                excl_pid.add(r["place_id"])
            ph = P.norm_phone(r.get("phone"))
            if ph:
                excl_ph.add(ph)
            excl_na.add((str(r.get("name") or "").lower().strip(),
                         str(r.get("address") or "").lower().strip()))
    print(f"exclusion sets: {len(excl_pid)} pids, {len(excl_ph)} phones")

    raw3 = load_dir(RAW6)
    print(f"raw6: {len(raw3)}")
    recs, seen_pid, seen_ph, seen_na = [], set(), set(), set()
    skipped = {"dup_in_batch": 0, "dup_earlier": 0, "junk": 0, "no_contact": 0}
    for r in raw3:
        pid, ph = r.get("place_id"), P.norm_phone(r.get("phone"))
        na = (str(r.get("name") or "").lower().strip(),
              str(r.get("address") or "").lower().strip())
        if (pid in seen_pid) or (ph and ph in seen_ph) or (na in seen_na):
            skipped["dup_in_batch"] += 1
            continue
        if (pid in excl_pid) or (ph and ph in excl_ph) or (na in excl_na):
            skipped["dup_earlier"] += 1
            continue
        if JUNK.search(str(r.get("name") or "")):
            skipped["junk"] += 1
            continue
        if not r.get("phone") and not r.get("website"):
            skipped["no_contact"] += 1
            continue
        seen_pid.add(pid); seen_na.add(na)
        if ph:
            seen_ph.add(ph)
        recs.append(r)
    print(f"qualified: {len(recs)}, skipped: {skipped}")

    sites = {}
    for r in recs:
        u = P.norm_url(r.get("website"))
        if u and P.urlparse(u).netloc.lower().replace("www.", "") not in P.SOCIAL_DOMAINS:
            sites.setdefault(P.site_key(u), u)
    print(f"probing {len(sites)} sites")
    probes = {}
    with ThreadPoolExecutor(max_workers=12) as ex:
        for k, pr in zip(sites.keys(), ex.map(P.probe, sites.values())):
            probes[k] = pr
    print(f"websites OK: {sum(1 for p in probes.values() if p['ok'])}/{len(probes)}")

    leads = P.build_leads(recs, probes)
    order = {"Hot": 0, "Warm": 1, "Cold": 2}
    leads.sort(key=lambda l: (order[l["tier"]], -l["score"],
                              -(l["review_count"] if isinstance(l["review_count"], int) else 0),
                              l["name"]))
    json.dump(leads, open(os.path.join(OUT, "gyms-delhi-2026-10-23-set6.json"), "w"),
              ensure_ascii=False)
    top, rest = leads[:LIMIT], leads[LIMIT:]
    hot = sum(1 for l in top if l["tier"] == "Hot")
    warm = sum(1 for l in top if l["tier"] == "Warm")
    cold = sum(1 for l in top if l["tier"] == "Cold")
    print(f"exporting {len(top)} (Hot={hot} Warm={warm} Cold={cold}), remaining: {len(rest)}")

    existing = P.ensure_tab()
    rows = [[BATCH_DATE, BATCH_LABEL] + P.row(l) for l in top]
    failed, CH, base = [], 20, existing + 1
    for i in range(0, len(rows), CH):
        chunk = rows[i:i + CH]
        f = P.write_chunk(P.NEW_TAB, base + i, chunk)
        failed.extend(f)
        print(f"rows {base + i}-{base + i + len(chunk) - 1}: {'FAILED ' + str(f) if f else 'ok'}")
    cur = P.cli("spreadsheets", "values", "get", "--params",
                json.dumps({"spreadsheetId": P.SHEET_ID, "range": f"{P.NEW_TAB}!A1:A10000"}))
    print(f"tab rows now: {len(cur.get('values', []))}")
    if failed:
        print(f"FAILED ROW RANGES: {failed}")
    else:
        print("round 3 batch complete, no write failures")

if __name__ == "__main__":
    main()
