# Solvrex — Instagram stage (built into the one-shot flow)

Instagram research is NO LONGER optional. In one-shot mode it runs as
step 10 of SOP.md on every batch. This file holds its detailed rules.

## Research (public info first)
1. Load the batch leads as-is. Do NOT re-score or alter original scores.
2. For each business, find the official Instagram profile:
   - First check the business website for instagram.com links (fast).
   - Else search: site:instagram.com "[Name]" "[Area]",
     "[Name]" [category] [city] instagram, "[Name]" official Instagram.
   - Never bypass login walls or CAPTCHAs to get this data.
   - Record: handle, profile URL, match status
     (Verified Match / Probable Match / Not Found / Unable to Verify),
     source URL.
   - Never invent handles, counts, or dates.
3. A missing Instagram is a legitimate finding (hook = build presence
   from scratch) — never auto-reject a prospect for it.

## Live visits (real numbers, not estimates)
1. The user logs in to Instagram in the browser through the secure
   prompt. The agent NEVER sees the password and NEVER logs out
   mid-sweep — the session is needed until the last batch finishes.
2. Visit each found profile in the logged-in browser, in batches of
   ~40, at human pace (~5s between profiles).
3. Record per profile: followers, following, total posts, bio (short),
   the 3 most recent posts (date, type, short caption), Reels
   (yes/no/unknown).
4. For repeated handles (chain accounts appearing for several
   branches), record counts once and "same as before" afterwards.
5. Statuses: ok (full profile), gone (profile deleted/unavailable),
   location_page (a Maps-style location page, not a business profile),
   private (counts only, posts not visible), not_instagram (link
   wasn't Instagram at all).
6. STOP RULE: on any "Try again later", action block, CAPTCHA, or
   logout, STOP the batch immediately and report how many were done
   and why it stopped. Never force through a block.
7. Work with checkpoint files (JSON per batch) so an interruption
   resumes without redoing visits.

## Derived fields (from visit data only)
- Last Post Date = the latest date among the 3 recent posts. Reports
  are not always date-ordered — take the max.
- Posting Frequency = derived from the gaps between the 3 post dates:
  Very active (about every 1–3 days), Active (about every 4–10 days),
  Occasional (about every 11–30 days), Inactive (last 3 posts span
  30+ days). No posts = "No posts". Private = "Not visible (private
  account)". No profile = "No Instagram presence".
- Never extrapolate beyond the observed posts.

## Output
The Instagram columns go INTO the visualization Excel (SOP.md step
11): Instagram Handle, Instagram Link, Followers, Number of Posts,
Last Post Date, Posting Frequency — alongside Contact Number and
Email. Dashboard carries honest Instagram coverage metrics
(e.g. "89 with live data / 396 with no profile").
Report real coverage honestly — never fabricate findings to fill gaps.

## Standing rules carried over
- WhatsApp ping on completion with the key result.
- A missing profile is the strongest social-media sales angle.
  Say so in the delivery message.
