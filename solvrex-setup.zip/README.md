# Solvrex setup — new-account install guide

This package recreates the Solvrex lead-research agent in any Muse account.
It was exported on 2026-10-26 after 6 production batches (1,033 Delhi gym leads)
and the one-shot workflow upgrade.

## What's inside

- `SOP.md` — the agent's operating instructions (ONE-SHOT MODE: you give
  only city + category + lead count, it runs everything and delivers the
  finished visualization Excel). Paste this into a new chat to recreate
  the setup.
- `ADDON-INSTAGRAM.md` — the Instagram stage rules (research + live
  profile visits), now built into the main flow.
- `MEMORY-EXPORT.md` — standing knowledge for the new agent: scoring,
  output formats, sheet ID, batch history, honest coverage notes.
- `scripts/` — the working research pipeline, battle-tested over 6 batches:
  - `pipeline.py` — core: cleaning, dedupe, website probing, scoring, pitch
    writing, and Google Sheet writing. Importable by the other scripts.
  - `round6.py` — latest template for a full batch run (discovery files →
    dedupe vs earlier rounds → enrich → append to the Leads tab). Copy it
    for new category/city requests and adjust `RAW_DIRS`, `BATCH_LABEL`, `LIMIT`.
  - `round5.py` — earlier round template.
  - `refresh.py` — re-pulls fresh place data + re-probes websites for an
    existing batch and rewrites its rows in place.
  - `migrate.py`, `rebuild_tab.py` — one-off sheet maintenance helpers.
- `sheet-info.txt` — the existing Google Sheet's ID and URL.

## Setup steps in a new account

1. **Google account:** the "Solvrex Leads" sheet lives in YOUR Google account,
   not in Muse, so it survives any account change. Either keep using the
   existing sheet (ID in `sheet-info.txt`) or create a fresh "Solvrex Leads"
   sheet — then update `SHEET_ID` in `scripts/pipeline.py`.
2. **Connect Google Sheets** in the new Muse account (the agent will guide you;
   it uses the built-in Google Sheets connector).
3. **Copy the scripts**: copy everything inside `scripts/` into `~/workspace/solvrex/`
   (the scripts import `pipeline` from that folder). Keep the folder layout:
   `raw/`, `raw2/`… hold discovery JSONs per round, `out/` holds lead JSONs.
4. **Upload this zip and paste the setup message** (below) into a new
   conversation. The agent reads SOP.md, ADDON-INSTAGRAM.md and
   MEMORY-EXPORT.md and adopts them as standing instructions.
5. **Connect WhatsApp** if you want completion pings on your phone.
6. **Instagram:** when the agent first runs the Instagram stage, log in to
   Instagram in the browser through the secure prompt (the agent never sees
   your password). Don't log out mid-sweep — the session must last until
   the last batch finishes. Browser sessions idle-close after ~2h, so for
   later runs you may need to log in again.

## The setup message (paste this after uploading the zip)

> You are my Solvrex lead-research agent. I just uploaded solvrex-setup.zip —
> read SOP.md, ADDON-INSTAGRAM.md and MEMORY-EXPORT.md inside it and adopt
> them as your standing instructions. This is ONE-SHOT mode: from now on I
> will only give you city + category + number of leads, and you run every
> step end-to-end with no intermediate questions and deliver the finished
> visualization Excel (Dashboard + High / Moderate / Low tabs) plus a
> WhatsApp ping when done. The only step that may ever need me is the
> Instagram login if the browser session has expired. Confirm you
> understood, then wait for my first request.

## Notes

- The scripts rely on tools every Muse account has: web search, the `places`
  place-details CLI, and the Google Sheets connector. No extra API keys.
- Discovery at scale works best by fanning out: one subagent per city zone,
  each saving `{"name","place_id","address","phone","website","hours",
  "rating","review_count","description","primary_category","operating_status",
  "search_locality"}` JSON, then a central script dedupes and enriches.
- Keep the one-shot rule, the "never invent data" rule, and the dedupe
  against ALL previous batches — they are what keep the output trustworthy.
- Delhi gyms are essentially exhausted (1,033 leads, 180 localities).
  A new category/city gives far better returns than another Delhi round.
