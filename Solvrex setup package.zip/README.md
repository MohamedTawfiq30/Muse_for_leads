# Solvrex setup — new-account install guide

This package recreates the Solvrex lead-research agent in any Muse account.
It was exported on 2026-10-23 after 5 production batches (933 Delhi gym leads).

## What's inside

- `SOP.md` — the agent's operating instructions. Paste this into a new chat
  (or save it where your agent keeps long-term instructions) to recreate the setup.
- `scripts/` — the working research pipeline, battle-tested over 5 batches:
  - `pipeline.py` — core: cleaning, dedupe, website probing, scoring, pitch
    writing, and Google Sheet writing. Importable by the other scripts.
  - `round5.py` — template for a full batch run (discovery files → dedupe vs
    earlier rounds → enrich → append to the Leads tab). Copy it for new
    category/city requests and adjust `RAW3`, `RAW_DIRS`, `BATCH_LABEL`, `LIMIT`.
  - `refresh.py` — re-pulls fresh place data + re-probes websites for an
    existing batch and rewrites its rows in place.
  - `migrate.py`, `rebuild_tab.py` — one-off sheet maintenance helpers.
- `sheet-info.txt` — the existing Google Sheet's ID and URL.

## Setup steps in a new account

1. **Google account:** the "Solvrex Leads" sheet lives in YOUR Google account,
   not in Muse, so it survives any account change. Either keep using the
   existing sheet (ID in `sheet-info.txt`) or create a fresh "Solvrex Leads"
   sheet — then update `SHEET_ID` in `scripts/pipeline.py`.
2. **Connect Google Sheets** in the new Muse account (the agent will guide you;
   it uses the built-in Google Sheets connector).
3. **Copy the scripts**: copy everything inside `scripts/` into `~/workspace/solvrex/`
   (the scripts import `pipeline` from that folder). Keep the folder layout:
   `raw/`, `raw2/`… hold discovery JSONs per round, `out/` holds lead JSONs.
4. **Paste `SOP.md`** into a new conversation and say "this is your operating
   procedure". The agent will ask any setup questions (it did here too).
5. **Connect WhatsApp** if you want completion pings on your phone.

## Notes

- The scripts rely on tools every Muse account has: web search, the `places`
  place-details CLI, and the Google Sheets connector. No extra API keys.
- Discovery at scale works best by fanning out: one subagent per city zone,
  each saving `{"name","place_id","address","phone","website","hours",
  "rating","review_count","description","primary_category","operating_status",
  "search_locality"}` JSON, then a central script dedupes and enriches.
- Keep the SOP's batching rule (100/request) and the "never invent data" rule —
  they are what keep the output trustworthy.
